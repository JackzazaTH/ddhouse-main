// This file is part of a legacy Vite setup and is not used in the Next.js application.
// Its content has been cleared to avoid confusion. The active constants are in /lib/constants.ts.