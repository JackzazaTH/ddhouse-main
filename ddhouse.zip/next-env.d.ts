// FIX: Temporarily commented out to resolve build errors related to missing type definitions.
// This is a workaround for an environment where 'next' types are not available.
// In a standard Next.js setup, these references should be active.
// /// <reference types="next" />
// /// <reference types="next/image-types/global" />

// NOTE: This file should not be edited
// see https://nextjs.org/docs/basic-features/typescript for more information.
